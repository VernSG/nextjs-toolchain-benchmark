#!/usr/bin/env python3
"""
Next.js Toolchain Benchmark - Chart Generator
=============================================

Generates publication-quality visualizations for the Webpack vs Turbopack
benchmark study. Outputs are suitable for academic papers and Zenodo deposits.

Author: Benchmark Automation Suite
Date: January 2026
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import os

# =============================================================================
# Configuration
# =============================================================================

# Output directory
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), '..', 'results', 'charts')

# Color palette (Vercel-inspired)
COLORS = {
    'webpack': '#3178C6',      # TypeScript Blue (representing legacy JS tooling)
    'turbopack': '#F21B3F',    # Vercel Red
    'webpack_light': '#6BA3E8',
    'turbopack_light': '#F76D85',
    'grid': '#E5E5E5',
    'text': '#1A1A1A',
    'annotation': '#666666'
}

# Data from benchmark results (N=30 per condition, except Medium Webpack N=28)
DATA = {
    'small': {
        'webpack': 163.27,
        'turbopack': 26.43,
        'n_webpack': 30,
        'n_turbopack': 30
    },
    'medium': {
        'webpack': 205.29,
        'turbopack': 24.07,
        'n_webpack': 28,  # 2 runs failed (timeout + regex mismatch)
        'n_turbopack': 30
    }
}

# =============================================================================
# Utility Functions
# =============================================================================

def setup_output_directory():
    """Create output directory if it doesn't exist."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"📁 Output directory: {os.path.abspath(OUTPUT_DIR)}")

def apply_professional_style(ax, title, xlabel, ylabel):
    """Apply consistent professional styling to axes."""
    ax.set_title(title, fontsize=14, fontweight='bold', color=COLORS['text'], pad=20)
    ax.set_xlabel(xlabel, fontsize=11, color=COLORS['text'], labelpad=10)
    ax.set_ylabel(ylabel, fontsize=11, color=COLORS['text'], labelpad=10)
    
    # Grid styling
    ax.grid(True, linestyle='-', alpha=0.3, color=COLORS['grid'], zorder=0)
    ax.set_axisbelow(True)
    
    # Spine styling
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    for spine in ['bottom', 'left']:
        ax.spines[spine].set_color(COLORS['grid'])
        ax.spines[spine].set_linewidth(1.5)
    
    # Tick styling
    ax.tick_params(axis='both', which='major', labelsize=10, colors=COLORS['text'])

# =============================================================================
# Chart 1: Bar Chart Comparison
# =============================================================================

def generate_bar_chart():
    """
    Generate grouped bar chart comparing HMR latency between Webpack and Turbopack
    for Small and Medium project sizes.
    """
    print("\n📊 Generating Bar Chart: HMR Latency Comparison...")
    
    # Data preparation
    categories = ['Small Project\n(~10 components)', 'Medium Project\n(50 components)']
    webpack_values = [DATA['small']['webpack'], DATA['medium']['webpack']]
    turbopack_values = [DATA['small']['turbopack'], DATA['medium']['turbopack']]
    
    # Calculate speedup factors
    speedups = [w/t for w, t in zip(webpack_values, turbopack_values)]
    
    # Figure setup
    fig, ax = plt.subplots(figsize=(10, 7), dpi=300)
    
    # Bar positioning
    x = np.arange(len(categories))
    bar_width = 0.35
    
    # Create bars
    bars_webpack = ax.bar(
        x - bar_width/2, 
        webpack_values, 
        bar_width, 
        label='Webpack (Legacy)', 
        color=COLORS['webpack'],
        edgecolor='white',
        linewidth=1.5,
        zorder=3
    )
    
    bars_turbopack = ax.bar(
        x + bar_width/2, 
        turbopack_values, 
        bar_width, 
        label='Turbopack', 
        color=COLORS['turbopack'],
        edgecolor='white',
        linewidth=1.5,
        zorder=3
    )
    
    # Add value labels on bars
    def add_bar_labels(bars, values, offset=5):
        for bar, val in zip(bars, values):
            height = bar.get_height()
            ax.annotate(
                f'{val:.2f} ms',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, offset),
                textcoords="offset points",
                ha='center', 
                va='bottom',
                fontsize=11,
                fontweight='bold',
                color=COLORS['text']
            )
    
    add_bar_labels(bars_webpack, webpack_values)
    add_bar_labels(bars_turbopack, turbopack_values)
    
    # Add speedup annotations
    for i, (x_pos, speedup) in enumerate(zip(x, speedups)):
        ax.annotate(
            f'{speedup:.2f}× faster',
            xy=(x_pos, max(webpack_values[i], turbopack_values[i]) + 25),
            ha='center',
            fontsize=10,
            fontstyle='italic',
            color=COLORS['turbopack'],
            fontweight='bold'
        )
    
    # Styling
    apply_professional_style(
        ax,
        'HMR Latency Comparison: Webpack vs Turbopack',
        'Project Size',
        'HMR Latency (ms)'
    )
    
    ax.set_xticks(x)
    ax.set_xticklabels(categories)
    ax.set_ylim(0, max(webpack_values) * 1.35)
    
    # Legend
    legend = ax.legend(
        loc='upper left',
        frameon=True,
        framealpha=0.95,
        edgecolor=COLORS['grid'],
        fontsize=10
    )
    legend.get_frame().set_linewidth(1.5)
    
    # Add methodology note
    fig.text(
        0.5, 0.02,
        'Data: N=30 samples per condition | Platform: Apple M1 | Framework: Next.js 14',
        ha='center',
        fontsize=9,
        color=COLORS['annotation'],
        style='italic'
    )
    
    # Save
    plt.tight_layout(rect=[0, 0.05, 1, 1])
    output_path = os.path.join(OUTPUT_DIR, 'chart1_hmr_comparison.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"   ✅ Saved: {output_path}")
    return output_path

# =============================================================================
# Chart 2: Scalability Trend Line Chart
# =============================================================================

def generate_scalability_chart():
    """
    Generate line chart showing scalability comparison between Small and Medium projects.
    Uses only measured data (no projections).
    """
    print("\n📈 Generating Line Chart: Scalability Comparison (Measured Data Only)...")
    
    # Data preparation - MEASURED DATA ONLY
    project_sizes = ['Small Project\n(~10 components)', 'Medium Project\n(50 components)']
    x_positions = np.array([0, 1])
    
    webpack_values = [
        DATA['small']['webpack'],
        DATA['medium']['webpack']
    ]
    
    turbopack_values = [
        DATA['small']['turbopack'],
        DATA['medium']['turbopack']
    ]
    
    # Calculate percentage changes
    webpack_change = ((webpack_values[1] - webpack_values[0]) / webpack_values[0]) * 100
    turbopack_change = ((turbopack_values[1] - turbopack_values[0]) / turbopack_values[0]) * 100
    
    # Calculate speedup factors
    speedup_small = webpack_values[0] / turbopack_values[0]
    speedup_medium = webpack_values[1] / turbopack_values[1]
    
    # Figure setup
    fig, ax = plt.subplots(figsize=(10, 7), dpi=300)
    
    # Plot Webpack line
    ax.plot(
        x_positions, webpack_values,
        color=COLORS['webpack'],
        linewidth=3,
        marker='o',
        markersize=14,
        markerfacecolor=COLORS['webpack'],
        markeredgecolor='white',
        markeredgewidth=2,
        label='Webpack (Legacy)',
        zorder=5
    )
    
    # Plot Turbopack line
    ax.plot(
        x_positions, turbopack_values,
        color=COLORS['turbopack'],
        linewidth=3,
        marker='o',
        markersize=14,
        markerfacecolor=COLORS['turbopack'],
        markeredgecolor='white',
        markeredgewidth=2,
        label='Turbopack',
        zorder=5
    )
    
    # Add value annotations for Webpack
    for i, wp in enumerate(webpack_values):
        ax.annotate(
            f'{wp:.2f} ms',
            xy=(x_positions[i], wp),
            xytext=(0, 15),
            textcoords='offset points',
            fontsize=11,
            fontweight='bold',
            color=COLORS['webpack'],
            ha='center'
        )
    
    # Add value annotations for Turbopack
    for i, tp in enumerate(turbopack_values):
        ax.annotate(
            f'{tp:.2f} ms',
            xy=(x_positions[i], tp),
            xytext=(0, -20),
            textcoords='offset points',
            fontsize=11,
            fontweight='bold',
            color=COLORS['turbopack'],
            ha='center'
        )
    
    # Add scaling behavior annotations (without O notation claims)
    ax.annotate(
        f'Webpack: +{webpack_change:.1f}%\n(latency increased)',
        xy=(0.5, 185),
        fontsize=10,
        color=COLORS['webpack'],
        ha='center',
        fontweight='bold',
        bbox=dict(
            boxstyle='round,pad=0.4',
            facecolor='white',
            edgecolor=COLORS['webpack'],
            alpha=0.9
        )
    )
    
    ax.annotate(
        f'Turbopack: {turbopack_change:.1f}%\n(latency stable)',
        xy=(0.5, 45),
        fontsize=10,
        color=COLORS['turbopack'],
        ha='center',
        fontweight='bold',
        bbox=dict(
            boxstyle='round,pad=0.4',
            facecolor='white',
            edgecolor=COLORS['turbopack'],
            alpha=0.9
        )
    )
    
    # Add speedup factor annotations
    ax.annotate(
        f'{speedup_small:.2f}× faster',
        xy=(0, (webpack_values[0] + turbopack_values[0]) / 2),
        xytext=(-60, 0),
        textcoords='offset points',
        fontsize=10,
        color=COLORS['annotation'],
        ha='center',
        va='center',
        bbox=dict(
            boxstyle='round,pad=0.3',
            facecolor='#E8F5E9',
            edgecolor=COLORS['grid'],
            alpha=0.9
        )
    )
    
    ax.annotate(
        f'{speedup_medium:.2f}× faster',
        xy=(1, (webpack_values[1] + turbopack_values[1]) / 2),
        xytext=(60, 0),
        textcoords='offset points',
        fontsize=10,
        color=COLORS['annotation'],
        ha='center',
        va='center',
        bbox=dict(
            boxstyle='round,pad=0.3',
            facecolor='#E8F5E9',
            edgecolor=COLORS['grid'],
            alpha=0.9
        )
    )
    
    # Fill area between curves to emphasize the gap
    ax.fill_between(
        x_positions,
        turbopack_values,
        webpack_values,
        alpha=0.15,
        color=COLORS['turbopack'],
        zorder=1,
        label='Performance Gap'
    )
    
    # Styling
    apply_professional_style(
        ax,
        'HMR Scalability: Measured Performance Across Project Sizes',
        'Project Size',
        'HMR Latency (ms)'
    )
    
    ax.set_xticks(x_positions)
    ax.set_xticklabels(project_sizes)
    ax.set_ylim(0, 260)
    ax.set_xlim(-0.4, 1.4)
    
    # Add horizontal reference line at 100ms (human perception threshold)
    ax.axhline(
        y=100, 
        color=COLORS['annotation'], 
        linestyle=':', 
        linewidth=1.5, 
        alpha=0.7,
        zorder=2
    )
    ax.annotate(
        'Human Perception Threshold (~100ms)',
        xy=(1.35, 105),
        fontsize=8,
        color=COLORS['annotation'],
        ha='right',
        style='italic'
    )
    
    # Legend
    legend = ax.legend(
        loc='upper left',
        frameon=True,
        framealpha=0.95,
        edgecolor=COLORS['grid'],
        fontsize=10
    )
    legend.get_frame().set_linewidth(1.5)
    
    # Add methodology note
    fig.text(
        0.5, 0.02,
        'All data points are empirically measured | Small: N=30 | Medium: Webpack N=28, Turbopack N=30',
        ha='center',
        fontsize=9,
        color=COLORS['annotation'],
        style='italic'
    )
    
    # Save
    plt.tight_layout(rect=[0, 0.05, 1, 1])
    output_path = os.path.join(OUTPUT_DIR, 'chart2_scalability_projection.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"   ✅ Saved: {output_path}")
    return output_path

# =============================================================================
# Chart 3 (Bonus): Summary Infographic
# =============================================================================

def generate_summary_chart():
    """
    Generate a summary infographic combining key metrics.
    """
    print("\n🎨 Generating Summary Infographic...")
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 5), dpi=300)
    
    # --- Panel 1: Cold Start Comparison ---
    ax1 = axes[0]
    cold_start_data = {
        'Webpack': 1285.30,
        'Turbopack': 569.27
    }
    
    bars = ax1.barh(
        list(cold_start_data.keys()),
        list(cold_start_data.values()),
        color=[COLORS['webpack'], COLORS['turbopack']],
        edgecolor='white',
        linewidth=2,
        height=0.5
    )
    
    for bar, val in zip(bars, cold_start_data.values()):
        ax1.text(
            val + 30, bar.get_y() + bar.get_height()/2,
            f'{val:.0f} ms',
            va='center',
            fontsize=11,
            fontweight='bold'
        )
    
    ax1.set_xlim(0, 1600)
    ax1.set_title('Cold Start Time', fontsize=12, fontweight='bold', pad=15)
    ax1.set_xlabel('Time (ms)', fontsize=10)
    
    # Speedup badge
    ax1.text(
        800, -0.5,
        '2.26× faster',
        fontsize=10,
        fontweight='bold',
        color=COLORS['turbopack'],
        ha='center'
    )
    
    # --- Panel 2: HMR Speedup Factor (Measured Only) ---
    ax2 = axes[1]
    
    speedup_data = {
        'Small\n(~10 comp)': 6.18,
        'Medium\n(50 comp)': 8.53
    }
    
    bars = ax2.bar(
        list(speedup_data.keys()),
        list(speedup_data.values()),
        color=[COLORS['turbopack'], COLORS['turbopack']],
        edgecolor='white',
        linewidth=2,
        width=0.5
    )
    
    for bar, val in zip(bars, speedup_data.values()):
        ax2.text(
            bar.get_x() + bar.get_width()/2,
            bar.get_height() + 0.3,
            f'{val:.2f}×',
            ha='center',
            fontsize=12,
            fontweight='bold',
            color=COLORS['turbopack']
        )
    
    # Add growth annotation
    ax2.annotate(
        '+38% speedup\nincrease',
        xy=(0.5, 7.5),
        fontsize=9,
        ha='center',
        color=COLORS['annotation'],
        style='italic'
    )
    
    ax2.set_ylim(0, 12)
    ax2.set_title('Turbopack Speedup Factor\n(Measured)', fontsize=12, fontweight='bold', pad=15)
    ax2.set_ylabel('Speedup (×)', fontsize=10)
    
    # --- Panel 3: Key Metrics Summary ---
    ax3 = axes[2]
    ax3.axis('off')
    
    summary_text = """
    KEY FINDINGS
    ════════════════════════
    
    🚀 Cold Start
       2.26× faster
       
    ⚡ HMR (Small Project)
       6.18× faster
       
    📈 HMR (Medium Project)
       8.53× faster
       
    📊 Speedup Growth
       +38% (Small → Medium)
       
    ════════════════════════
    
    Platform: Apple M1
    Framework: Next.js 14
    Sample Size: N=30 (N=28*)
    
    * 2 Webpack runs failed
    """
    
    ax3.text(
        0.5, 0.5,
        summary_text,
        transform=ax3.transAxes,
        fontsize=11,
        fontfamily='monospace',
        verticalalignment='center',
        horizontalalignment='center',
        bbox=dict(
            boxstyle='round,pad=0.5',
            facecolor='#F8F9FA',
            edgecolor=COLORS['grid'],
            linewidth=2
        )
    )
    
    ax3.set_title('Summary', fontsize=12, fontweight='bold', pad=15)
    
    # Apply styling to first two panels
    for ax in [ax1, ax2]:
        ax.grid(True, linestyle='-', alpha=0.3, color=COLORS['grid'], zorder=0)
        ax.set_axisbelow(True)
        for spine in ['top', 'right']:
            ax.spines[spine].set_visible(False)
        for spine in ['bottom', 'left']:
            ax.spines[spine].set_color(COLORS['grid'])
    
    # Main title
    fig.suptitle(
        'Next.js Toolchain Benchmark: Webpack vs Turbopack',
        fontsize=14,
        fontweight='bold',
        y=1.02
    )
    
    # Save
    plt.tight_layout()
    output_path = os.path.join(OUTPUT_DIR, 'chart3_summary_infographic.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    
    print(f"   ✅ Saved: {output_path}")
    return output_path

# =============================================================================
# Main Execution
# =============================================================================

def main():
    """Generate all benchmark visualization charts."""
    print("=" * 60)
    print("  NEXT.JS TOOLCHAIN BENCHMARK - CHART GENERATOR")
    print("=" * 60)
    
    # Setup
    setup_output_directory()
    
    # Generate charts
    charts = []
    charts.append(generate_bar_chart())
    charts.append(generate_scalability_chart())
    charts.append(generate_summary_chart())
    
    # Summary
    print("\n" + "=" * 60)
    print("  GENERATION COMPLETE")
    print("=" * 60)
    print(f"\n📊 Generated {len(charts)} charts:")
    for chart in charts:
        print(f"   • {os.path.basename(chart)}")
    print(f"\n📁 Output location: {os.path.abspath(OUTPUT_DIR)}")
    print("\n✨ Charts are ready for publication (300 DPI, PNG format)")

if __name__ == "__main__":
    main()